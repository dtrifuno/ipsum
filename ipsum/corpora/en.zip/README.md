# 100 English Novels ver. 1.4

A benchmark corpus of 100 English novels, covering the 19th and the beginning of the 20th century. It contains novels by 33 authors (1/3 female writers, 2/3 male writers), and one anonymous (well, not so much...) novel entitled "Clara Vaughan".

The corpus is aimed at stylometric benchmarks. See:
[https://computationalstylistics.github.io/resources/](https://computationalstylistics.github.io/resources/)
for further details.
