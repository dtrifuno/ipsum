68 German Novels
=================

A benchmark corpus of 68 German novels, covering the 19th and the beginning of the 20th century. All texts are compliant with the Unicode (UTF-8).

The corpus is aimed at stylometric benchmarks. See:
https://sites.google.com/site/computationalstylistics/
for further details.
